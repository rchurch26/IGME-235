// class Asteroid extends PIXI.Graphics
// {
//     constructor()
// }